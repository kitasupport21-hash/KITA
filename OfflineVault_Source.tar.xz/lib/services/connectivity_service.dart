import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/widgets.dart';

class ConnectivityService extends ChangeNotifier with WidgetsBindingObserver {
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  List<ConnectivityResult> results = [ConnectivityResult.none];

  bool get online => results.any((result) => result != ConnectivityResult.none);
  bool get onWifi => results.contains(ConnectivityResult.wifi);

  Future<void> initialize() async {
    WidgetsBinding.instance.addObserver(this);
    await refresh();
    _subscription = _connectivity.onConnectivityChanged.listen((value) {
      results = value;
      notifyListeners();
    }, onError: (_) {
      results = [ConnectivityResult.none];
      notifyListeners();
    });
  }

  Future<void> refresh() async {
    try {
      results = await _connectivity.checkConnectivity();
    } catch (_) {
      results = [ConnectivityResult.none];
    }
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      refresh();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _subscription?.cancel();
    super.dispose();
  }
}
