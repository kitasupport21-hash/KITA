import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  int depth = 1;
  bool wifiOnly = false;
  bool darkMode = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    depth = prefs.getInt('depth') ?? 1;
    wifiOnly = prefs.getBool('wifiOnly') ?? false;
    darkMode = prefs.getBool('darkMode') ?? false;
    notifyListeners();
  }

  Future<void> setDepth(int value) async {
    depth = value.clamp(1, 3).toInt();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('depth', depth);
    notifyListeners();
  }

  Future<void> setWifiOnly(bool value) async {
    wifiOnly = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('wifiOnly', value);
    notifyListeners();
  }

  Future<void> setDarkMode(bool value) async {
    darkMode = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', value);
    notifyListeners();
  }
}
