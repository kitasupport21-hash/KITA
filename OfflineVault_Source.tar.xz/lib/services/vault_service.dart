import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../database/vault_database.dart';
import '../models/saved_item.dart';

class DownloadProgress {
  final String url;
  final int completed;
  final int total;
  final String message;

  const DownloadProgress(this.url, this.completed, this.total, this.message);

  double get fraction => total <= 0 ? 0 : (completed / total).clamp(0.0, 1.0).toDouble();
}

class _PageSnapshot {
  final Uri uri;
  final String relativePath;
  final dom.Document document;

  const _PageSnapshot({
    required this.uri,
    required this.relativePath,
    required this.document,
  });
}

class VaultService extends ChangeNotifier {
  VaultService({http.Client? client}) : _client = client ?? http.Client();

  final VaultDatabase _database = VaultDatabase.instance;
  final http.Client _client;

  List<SavedItem> items = [];
  DownloadProgress? progress;
  bool downloading = false;
  String? lastError;

  Directory? _root;
  bool _cancelRequested = false;
  Completer<void>? _activeAbort;
  Completer<void>? _downloadFinished;

  Future<void> initialize() async {
    final documents = await getApplicationDocumentsDirectory();
    _root = Directory(p.join(documents.path, 'OfflineVault'));
    await _root!.create(recursive: true);
    await _database.initialize();
    await refresh();
  }

  Future<void> refresh() async {
    items = await _database.all();
    notifyListeners();
  }

  Future<int> get storageUsed async {
    final root = _root;
    if (root == null || !await root.exists()) return 0;
    var total = 0;
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // A file may be removed while storage is being calculated.
        }
      }
    }
    return total;
  }

  Future<void> rename(SavedItem item, String title) async {
    final cleaned = title.trim();
    if (item.id == null || cleaned.isEmpty) return;
    await _database.rename(item.id!, cleaned);
    await refresh();
  }

  Future<void> delete(SavedItem item) async {
    if (item.id == null) return;
    final directory = Directory(item.folder);
    if (await directory.exists()) {
      await directory.delete(recursive: true);
    }
    await _database.delete(item.id!);
    await refresh();
  }

  Future<void> clearAll() async {
    if (downloading) {
      cancelDownload();
      await (_downloadFinished?.future ?? Future<void>.value());
    }
    final root = _root;
    if (root != null && await root.exists()) {
      await for (final entity in root.list()) {
        await entity.delete(recursive: true);
      }
    }
    await _database.clear();
    await refresh();
  }

  void cancelDownload() {
    _cancelRequested = true;
    final abort = _activeAbort;
    if (abort != null && !abort.isCompleted) {
      abort.complete();
    }
  }

  Future<http.Response> _get(Uri uri, {Duration timeout = const Duration(seconds: 25)}) async {
    _throwIfCancelled();
    final abort = Completer<void>();
    _activeAbort = abort;
    final request = http.AbortableRequest(
      'GET',
      uri,
      abortTrigger: abort.future,
    )
      ..headers['User-Agent'] = 'OfflineVault/1.0 (Android offline reader)'
      ..headers['Accept'] = 'text/html,application/xhtml+xml,text/css,application/javascript,image/*,*/*;q=0.8';

    try {
      final streamed = await _client.send(request).timeout(timeout);
      final bytes = await streamed.stream.toBytes().timeout(timeout);
      _throwIfCancelled();
      return http.Response.bytes(
        bytes,
        streamed.statusCode,
        headers: streamed.headers,
        request: streamed.request,
        isRedirect: streamed.isRedirect,
        persistentConnection: streamed.persistentConnection,
        reasonPhrase: streamed.reasonPhrase,
      );
    } on http.RequestAbortedException {
      throw Exception('Download cancelled.');
    } on TimeoutException {
      if (!abort.isCompleted) abort.complete();
      throw Exception('The server took too long to respond: $uri');
    } on SocketException {
      throw Exception('No internet connection or the website could not be reached.');
    } on http.ClientException {
      throw Exception('Could not connect to the website. Check your internet connection.');
    } on HandshakeException {
      throw Exception('Secure connection failed. Check the website certificate or try HTTPS.');
    } finally {
      if (identical(_activeAbort, abort)) _activeAbort = null;
    }
  }

  Future<SavedItem> saveWebsite(
    String input, {
    required bool wholeSite,
    required int depth,
  }) async {
    if (downloading) throw Exception('A download is already running.');
    final rootUri = _normalizeUri(input);
    final rootDirectory = _root;
    if (rootDirectory == null) throw StateError('OfflineVault storage is not ready.');

    _cancelRequested = false;
    lastError = null;
    downloading = true;
    _downloadFinished = Completer<void>();
    notifyListeners();

    final folder = Directory(
      p.join(rootDirectory.path, DateTime.now().microsecondsSinceEpoch.toString()),
    );

    final pages = <_PageSnapshot>[];
    final pagePaths = <String, String>{};
    final visited = <String>{};
    final queue = <({Uri uri, int level})>[(uri: rootUri, level: 0)];
    final assetPaths = <String, String>{};
    var firstTitle = rootUri.host;

    try {
      await folder.create(recursive: true);
      // Crawl pages breadth-first. The number of pages is capped to protect storage.
      while (queue.isNotEmpty) {
        _throwIfCancelled();
        final current = queue.removeAt(0);
        final requestUri = _withoutFragment(current.uri);
        final requestKey = requestUri.toString();
        if (!visited.add(requestKey)) continue;
        if (requestUri.host != rootUri.host) continue;
        if (visited.length > 100) break;

        progress = DownloadProgress(
          requestKey,
          pages.length,
          pages.length + queue.length + 1,
          'Downloading page ${pages.length + 1}',
        );
        notifyListeners();

        http.Response response;
        try {
          response = await _get(requestUri);
        } catch (_) {
          if (current.level == 0) rethrow;
          continue; // One unavailable linked page should not discard the whole archive.
        }
        if (response.statusCode == 404) {
          if (current.level == 0) {
            throw Exception('Page not found (404): $requestKey');
          }
          continue;
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          if (current.level == 0) {
            throw Exception('Server returned HTTP ${response.statusCode} for $requestKey');
          }
          continue;
        }
        final contentType = (response.headers['content-type'] ?? '').toLowerCase();
        if (!contentType.contains('text/html') && !contentType.contains('application/xhtml')) {
          if (current.level == 0) throw Exception('This URL does not return an HTML page.');
          continue;
        }

        final finalUri = _withoutFragment(response.request?.url ?? requestUri);
        final document = html_parser.parse(
          utf8.decode(response.bodyBytes, allowMalformed: true),
        );
        final title = document.querySelector('title')?.text.trim();
        if (firstTitle == rootUri.host && title != null && title.isNotEmpty) {
          firstTitle = title;
        }

        final relativePage = _pageRelativePath(finalUri);
        pagePaths[requestKey] = relativePage;
        pagePaths[finalUri.toString()] = relativePage;
        pages.add(_PageSnapshot(
          uri: finalUri,
          relativePath: relativePage,
          document: document,
        ));

        if (wholeSite && current.level < depth) {
          for (final anchor in document.querySelectorAll('a[href]')) {
            final href = anchor.attributes['href'];
            if (href == null || href.trim().isEmpty) continue;
            final candidate = _withoutFragment(finalUri.resolve(href.trim()));
            if ((candidate.scheme == 'http' || candidate.scheme == 'https') &&
                candidate.host == rootUri.host &&
                !_looksLikeDownload(candidate.path) &&
                !visited.contains(candidate.toString()) &&
                queue.length < 100) {
              queue.add((uri: candidate, level: current.level + 1));
            }
          }
        }
      }

      if (pages.isEmpty) throw Exception('No HTML page could be saved from this URL.');

      // Save assets and rewrite HTML references to paths inside this archive.
      for (var index = 0; index < pages.length; index++) {
        _throwIfCancelled();
        final page = pages[index];
        final htmlFile = File(p.join(folder.path, page.relativePath));
        await htmlFile.parent.create(recursive: true);
        final document = page.document;

        for (final base in document.querySelectorAll('base')) {
          base.remove();
        }

        final resourceElements = <dom.Element>[
          ...document.querySelectorAll('[src]'),
          ...document.querySelectorAll('[poster]'),
          ...document.querySelectorAll('link[href]'),
          ...document.querySelectorAll('a[href]'),
        ];

        for (final element in resourceElements) {
          _throwIfCancelled();
          final isAnchor = element.localName == 'a';
          final isLink = element.localName == 'link';
          final attr = element.attributes.containsKey('src')
              ? 'src'
              : (element.attributes.containsKey('poster') ? 'poster' : 'href');
          final raw = element.attributes[attr]?.trim();
          if (raw == null || raw.isEmpty || _isSpecialUrl(raw)) continue;

          final resolved = _withoutFragment(page.uri.resolve(raw));
          if (isAnchor) {
            final localPage = pagePaths[resolved.toString()];
            if (localPage != null) {
              element.attributes[attr] = _relativePath(
                htmlFile.path,
                p.join(folder.path, localPage),
              );
            }
            continue;
          }

          if (isLink) {
            final rel = (element.attributes['rel'] ?? '').toLowerCase();
            final shouldDownload = rel.contains('stylesheet') ||
                rel.contains('icon') || rel.contains('apple-touch-icon') ||
                rel.contains('preload');
            if (!shouldDownload) continue;
          }

          if (resolved.scheme != 'http' && resolved.scheme != 'https') continue;
          String? localAsset;
          try {
            localAsset = await _downloadAsset(
              resolved,
              folder,
              assetPaths,
              cssDepth: 0,
            );
          } catch (_) {
            // Keep the HTML page even when an individual resource cannot be fetched.
          }
          if (localAsset != null) {
            element.attributes[attr] = _relativePath(
              htmlFile.path,
              p.join(folder.path, localAsset),
            );
          }
        }

        // Rewrite CSS in style attributes and inline style blocks.
        for (final element in document.querySelectorAll('[style]')) {
          final style = element.attributes['style'];
          if (style != null) {
            element.attributes['style'] = await _rewriteCssText(
              style,
              page.uri,
              folder,
              htmlFile.path,
              assetPaths,
              cssDepth: 0,
            );
          }
        }
        for (final styleElement in document.querySelectorAll('style')) {
          styleElement.text = await _rewriteCssText(
            styleElement.text,
            page.uri,
            folder,
            htmlFile.path,
            assetPaths,
            cssDepth: 0,
          );
        }

        await htmlFile.writeAsString(document.outerHtml, flush: true);
        progress = DownloadProgress(
          page.uri.toString(),
          index + 1,
          pages.length,
          'Saving page ${index + 1} of ${pages.length}',
        );
        notifyListeners();
      }

      _throwIfCancelled();
      final mainRelativePath = pagePaths[_withoutFragment(rootUri).toString()];
      if (mainRelativePath == null) {
        throw Exception('The main page was not found in the downloaded pages.');
      }
      final entryFile = File(p.join(folder.path, mainRelativePath));
      if (!await entryFile.exists()) throw Exception('The downloaded HTML file is missing.');

      final totalBytes = await _directorySize(folder);
      final item = SavedItem(
        title: firstTitle,
        url: rootUri.toString(),
        folder: folder.path,
        entryPath: entryFile.path,
        savedAt: DateTime.now(),
        sizeBytes: totalBytes,
        pageCount: pages.length,
      );
      final rowId = await _database.insert(item);
      await refresh();
      return SavedItem(
        id: rowId,
        title: item.title,
        url: item.url,
        folder: item.folder,
        entryPath: item.entryPath,
        savedAt: item.savedAt,
        sizeBytes: item.sizeBytes,
        pageCount: item.pageCount,
      );
    } catch (error) {
      if (await folder.exists()) {
        await folder.delete(recursive: true);
      }
      lastError = error.toString().replaceFirst('Exception: ', '');
      rethrow;
    } finally {
      progress = null;
      downloading = false;
      final finished = _downloadFinished;
      if (finished != null && !finished.isCompleted) finished.complete();
      _downloadFinished = null;
      notifyListeners();
    }
  }

  Future<String?> _downloadAsset(
    Uri uri,
    Directory folder,
    Map<String, String> assetPaths, {
    required int cssDepth,
  }) async {
    _throwIfCancelled();
    final key = _withoutFragment(uri).toString();
    final existing = assetPaths[key];
    if (existing != null) return existing;
    if (uri.scheme != 'http' && uri.scheme != 'https') return null;

    final response = await _get(uri, timeout: const Duration(seconds: 18));
    if (response.statusCode < 200 || response.statusCode >= 300) return null;

    final contentType = (response.headers['content-type'] ?? '').toLowerCase();
    final extension = _safeExtension(uri.path, contentType);
    final fileName = 'res_${key.hashCode.toRadixString(16)}$extension';
    final relativePath = p.join('assets', fileName);
    final file = File(p.join(folder.path, relativePath));
    await file.parent.create(recursive: true);

    // Register before following CSS references to prevent recursive import loops.
    assetPaths[key] = relativePath;
    if (contentType.contains('text/css') || extension == '.css') {
      final css = utf8.decode(response.bodyBytes, allowMalformed: true);
      final rewritten = cssDepth >= 3
          ? css
          : await _rewriteCssText(
              css,
              response.request?.url ?? uri,
              folder,
              file.path,
              assetPaths,
              cssDepth: cssDepth + 1,
            );
      await file.writeAsString(rewritten, flush: true);
    } else {
      await file.writeAsBytes(response.bodyBytes, flush: true);
    }
    return relativePath;
  }

  Future<String> _rewriteCssText(
    String css,
    Uri baseUri,
    Directory folder,
    String sourceFilePath,
    Map<String, String> assetPaths, {
    required int cssDepth,
  }) async {
    final pattern = RegExp(r'''url\(\s*(['"]?)(.*?)\1\s*\)''', caseSensitive: false);
    final matches = pattern.allMatches(css).toList();
    var output = css;
    for (final match in matches.reversed) {
      final raw = (match.group(2) ?? '').trim();
      if (_isSpecialUrl(raw) || raw.startsWith('#')) continue;
      final uri = _withoutFragment(baseUri.resolve(raw));
      if (uri.scheme != 'http' && uri.scheme != 'https') continue;
      String? local;
      try {
        local = await _downloadAsset(
          uri,
          folder,
          assetPaths,
          cssDepth: cssDepth,
        );
      } catch (_) {
        continue;
      }
      if (local == null) continue;
      final localPath = _relativePath(
        sourceFilePath,
        p.join(folder.path, local),
      );
      output = output.replaceRange(
        match.start,
        match.end,
        'url("${localPath.replaceAll('\\', '/')}")',
      );
    }

    // Also capture the quoted form of @import "theme.css".
    final importPattern = RegExp(r'''@import\s+(['"])(.*?)\1''', caseSensitive: false);
    final imports = importPattern.allMatches(output).toList();
    for (final match in imports.reversed) {
      final raw = (match.group(2) ?? '').trim();
      if (_isSpecialUrl(raw)) continue;
      final uri = _withoutFragment(baseUri.resolve(raw));
      if (uri.scheme != 'http' && uri.scheme != 'https') continue;
      String? local;
      try {
        local = await _downloadAsset(
          uri,
          folder,
          assetPaths,
          cssDepth: cssDepth,
        );
      } catch (_) {
        continue;
      }
      if (local == null) continue;
      final localPath = _relativePath(
        sourceFilePath,
        p.join(folder.path, local),
      );
      output = output.replaceRange(
        match.start,
        match.end,
        '@import "${localPath.replaceAll('\\', '/')}"',
      );
    }
    return output;
  }

  Future<int> _directorySize(Directory directory) async {
    var total = 0;
    await for (final entity in directory.list(recursive: true, followLinks: false)) {
      if (entity is File) {
        try {
          total += await entity.length();
        } on FileSystemException {
          // Ignore an asset that was concurrently removed by the OS.
        }
      }
    }
    return total;
  }

  String _relativePath(String fromFile, String toFile) {
    return p.relative(toFile, from: p.dirname(fromFile)).replaceAll('\\', '/');
  }

  Uri _normalizeUri(String input) {
    var value = input.trim();
    if (value.isEmpty) throw Exception('Please enter a website URL.');
    if (!value.startsWith('http://') && !value.startsWith('https://')) {
      value = 'https://$value';
    }
    final uri = Uri.tryParse(value);
    if (uri == null || !uri.hasAuthority || uri.host.isEmpty ||
        (uri.scheme != 'http' && uri.scheme != 'https')) {
      throw Exception('Please enter a valid http or https URL.');
    }
    return _withoutFragment(uri);
  }

  Uri _withoutFragment(Uri uri) => uri.replace(fragment: '').normalizePath();

  String _pageRelativePath(Uri uri) {
    final rawSegments = uri.pathSegments.where((segment) => segment.isNotEmpty).toList();
    if (uri.path.isEmpty || uri.path.endsWith('/')) rawSegments.add('index.html');
    if (rawSegments.isEmpty) rawSegments.add('index.html');

    final safeSegments = rawSegments.map((segment) {
      final safe = segment.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'), '_');
      return safe == '.' || safe == '..' ? '_${safe.replaceAll('.', '')}' : safe;
    }).toList();

    var finalName = safeSegments.removeLast();
    if (!finalName.toLowerCase().endsWith('.html') &&
        !finalName.toLowerCase().endsWith('.htm')) {
      finalName = '$finalName.html';
    }
    if (uri.hasQuery) {
      finalName = '${finalName.substring(0, finalName.lastIndexOf('.'))}_q${uri.query.hashCode.toRadixString(16)}.html';
    }
    safeSegments.add(finalName);
    return p.joinAll(['pages', ...safeSegments]);
  }

  bool _looksLikeDownload(String path) => RegExp(
        r'\.(pdf|zip|rar|7z|mp4|m4v|mp3|wav|jpg|jpeg|png|gif|webp|svg|woff2?)$',
        caseSensitive: false,
      ).hasMatch(path);

  bool _isSpecialUrl(String value) {
    final lower = value.toLowerCase().trim();
    return lower.isEmpty || lower.startsWith('#') || lower.startsWith('data:') ||
        lower.startsWith('javascript:') || lower.startsWith('mailto:') ||
        lower.startsWith('tel:') || lower.startsWith('blob:') ||
        lower.startsWith('about:');
  }

  String _safeExtension(String path, String contentType) {
    final mime = contentType.split(';').first.trim();
    const mimeExtensions = <String, String>{
      'text/css': '.css',
      'application/javascript': '.js',
      'text/javascript': '.js',
      'application/x-javascript': '.js',
      'image/jpeg': '.jpg',
      'image/png': '.png',
      'image/gif': '.gif',
      'image/webp': '.webp',
      'image/svg+xml': '.svg',
      'image/x-icon': '.ico',
      'font/woff2': '.woff2',
      'font/woff': '.woff',
      'font/ttf': '.ttf',
      'application/font-woff': '.woff',
    };
    final mimeExtension = mimeExtensions[mime];
    if (mimeExtension != null) return mimeExtension;
    final extension = p.extension(path).toLowerCase();
    if (RegExp(r'^\.[a-z0-9]{1,8}$').hasMatch(extension)) return extension;
    return '.bin';
  }

  void _throwIfCancelled() {
    if (_cancelRequested) throw Exception('Download cancelled.');
  }

  @override
  void dispose() {
    cancelDownload();
    _client.close();
    super.dispose();
  }
}
