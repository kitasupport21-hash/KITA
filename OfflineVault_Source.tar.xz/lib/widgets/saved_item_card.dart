import 'package:flutter/material.dart';
import '../models/saved_item.dart';

class SavedItemCard extends StatelessWidget {
  final SavedItem item;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onDelete;
  const SavedItemCard({
    super.key, required this.item, required this.onOpen,
    required this.onRename, required this.onDelete,
  });

  String _size(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onOpen,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.offline_pin, color: Colors.green),
              const SizedBox(width: 10),
              Expanded(child: Text(item.title,
                style: Theme.of(context).textTheme.titleMedium,
                maxLines: 1, overflow: TextOverflow.ellipsis)),
              PopupMenuButton<String>(
                onSelected: (v) => v == 'rename' ? onRename() : onDelete(),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'rename', child: Text('Rename')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ]),
            const SizedBox(height: 6),
            Text(item.url, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 8),
            Wrap(spacing: 14, runSpacing: 4, children: [
              _meta(Icons.calendar_today, '${item.savedAt.toLocal()}'.split('.').first),
              _meta(Icons.storage, _size(item.sizeBytes)),
              _meta(Icons.article_outlined, '${item.pageCount} page(s)'),
            ]),
          ]),
        ),
      ),
    );
  }

  Widget _meta(IconData icon, String text) => Row(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, size: 13), const SizedBox(width: 4),
    Text(text, style: const TextStyle(fontSize: 11)),
  ]);
}
