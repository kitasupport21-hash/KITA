import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/vault_service.dart';
import 'services/connectivity_service.dart';
import 'services/settings_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = SettingsService();
  await settings.load();
  final vault = VaultService();
  await vault.initialize();
  final connectivity = ConnectivityService();
  await connectivity.initialize();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: settings),
        ChangeNotifierProvider.value(value: vault),
        ChangeNotifierProvider.value(value: connectivity),
      ],
      child: const OfflineVaultApp(),
    ),
  );
}

class OfflineVaultApp extends StatelessWidget {
  const OfflineVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsService>(
      builder: (context, settings, _) => MaterialApp(
        title: 'OfflineVault',
        debugShowCheckedModeBanner: false,
        themeMode: settings.darkMode ? ThemeMode.dark : ThemeMode.light,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF536DFE)),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFF6F7FB),
        ),
        darkTheme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF8C9EFF),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
