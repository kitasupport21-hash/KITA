class SavedItem {
  final int? id;
  final String title;
  final String url;
  final String folder;
  final String entryPath;
  final DateTime savedAt;
  final int sizeBytes;
  final int pageCount;

  const SavedItem({
    this.id,
    required this.title,
    required this.url,
    required this.folder,
    required this.entryPath,
    required this.savedAt,
    required this.sizeBytes,
    required this.pageCount,
  });

  factory SavedItem.fromMap(Map<String, Object?> map) => SavedItem(
        id: map['id'] as int?,
        title: map['title'] as String,
        url: map['url'] as String,
        folder: map['folder'] as String,
        entryPath: map['entry_path'] as String,
        savedAt: DateTime.fromMillisecondsSinceEpoch(map['saved_at'] as int),
        sizeBytes: map['size_bytes'] as int,
        pageCount: map['page_count'] as int,
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'url': url,
        'folder': folder,
        'entry_path': entryPath,
        'saved_at': savedAt.millisecondsSinceEpoch,
        'size_bytes': sizeBytes,
        'page_count': pageCount,
      };

  SavedItem copyWith({String? title}) => SavedItem(
        id: id,
        title: title ?? this.title,
        url: url,
        folder: folder,
        entryPath: entryPath,
        savedAt: savedAt,
        sizeBytes: sizeBytes,
        pageCount: pageCount,
      );
}
