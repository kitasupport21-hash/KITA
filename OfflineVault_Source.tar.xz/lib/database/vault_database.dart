import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/saved_item.dart';

class VaultDatabase {
  VaultDatabase._();
  static final VaultDatabase instance = VaultDatabase._();

  Database? _database;

  Future<void> initialize() async {
    if (_database != null) return;
    final databaseDirectory = await getDatabasesPath();
    _database = await openDatabase(
      p.join(databaseDirectory, 'offlinevault.db'),
      version: 2,
      onCreate: (database, version) async {
        await database.execute('''
          CREATE TABLE saved_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            url TEXT NOT NULL,
            folder TEXT NOT NULL,
            entry_path TEXT NOT NULL,
            saved_at INTEGER NOT NULL,
            size_bytes INTEGER NOT NULL,
            page_count INTEGER NOT NULL
          )
        ''');
      },
      onUpgrade: (database, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await database.execute(
            "ALTER TABLE saved_items ADD COLUMN entry_path TEXT NOT NULL DEFAULT ''",
          );
          await database.execute(
            "UPDATE saved_items SET entry_path = folder || '/index.html' WHERE entry_path = ''",
          );
        }
      },
    );
  }

  Database get _db {
    final database = _database;
    if (database == null) {
      throw StateError('Vault database has not been initialized.');
    }
    return database;
  }

  Future<List<SavedItem>> all() async {
    final rows = await _db.query('saved_items', orderBy: 'saved_at DESC');
    return rows.map(SavedItem.fromMap).toList(growable: false);
  }

  Future<int> insert(SavedItem item) async {
    final values = item.toMap()..remove('id');
    return _db.insert('saved_items', values);
  }

  Future<void> rename(int id, String title) async {
    await _db.update(
      'saved_items',
      {'title': title},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> delete(int id) async {
    await _db.delete('saved_items', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clear() async {
    await _db.delete('saved_items');
  }
}
