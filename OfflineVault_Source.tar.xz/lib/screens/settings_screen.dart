import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/settings_service.dart';
import '../services/vault_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  String _format(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    final vault = context.watch<VaultService>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text('Download depth', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 6),
        SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 1, label: Text('1')),
            ButtonSegment(value: 2, label: Text('2')),
            ButtonSegment(value: 3, label: Text('3')),
          ],
          selected: {settings.depth},
          onSelectionChanged: (v) => settings.setDepth(v.first),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Download only on Wi-Fi'),
          value: settings.wifiOnly,
          onChanged: settings.setWifiOnly,
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Dark mode'),
          value: settings.darkMode,
          onChanged: settings.setDarkMode,
        ),
        const Divider(height: 28),
        FutureBuilder<int>(
          future: vault.storageUsed,
          builder: (context, snapshot) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.storage),
            title: const Text('Storage used'),
            subtitle: Text(snapshot.hasData ? _format(snapshot.data!) : 'Calculating…'),
          ),
        ),
        const ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.info_outline),
          title: Text('OfflineVault'),
          subtitle: Text('Saved pages stay on this device.'),
        ),
      ]),
    );
  }
}
