import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/saved_item.dart';
import '../services/vault_service.dart';
import '../services/connectivity_service.dart';
import '../widgets/saved_item_card.dart';
import 'add_screen.dart';
import 'viewer_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _search = TextEditingController();
  String _sort = 'date';

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _rename(SavedItem item) async {
    final controller = TextEditingController(text: item.title);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename saved item'),
        content: TextField(controller: controller, autofocus: true,
          decoration: const InputDecoration(labelText: 'Title')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.trim().isNotEmpty && mounted) {
      await context.read<VaultService>().rename(item, value);
    }
  }

  Future<void> _delete(SavedItem item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete saved page?'),
        content: Text('Delete "${item.title}" and its downloaded files?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
        ],
      ),
    );
    if (yes == true && mounted) await context.read<VaultService>().delete(item);
  }

  Future<void> _clearAll() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear all saved content?'),
        content: const Text('This permanently deletes every saved page and downloaded file.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear all')),
        ],
      ),
    );
    if (yes == true && mounted) await context.read<VaultService>().clearAll();
  }

  @override
  Widget build(BuildContext context) {
    final vault = context.watch<VaultService>();
    final network = context.watch<ConnectivityService>();
    final query = _search.text.toLowerCase();
    final filtered = vault.items.where((item) =>
      item.title.toLowerCase().contains(query) || item.url.toLowerCase().contains(query)
    ).toList();
    filtered.sort((a, b) => _sort == 'name'
      ? a.title.toLowerCase().compareTo(b.title.toLowerCase())
      : b.savedAt.compareTo(a.savedAt));

    return Scaffold(
      appBar: AppBar(
        title: const Text('OfflineVault', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 15),
            child: Chip(
              avatar: Icon(network.online ? Icons.wifi : Icons.wifi_off, size: 16,
                color: network.online ? Colors.green : Colors.red),
              label: Text(network.online ? 'Online' : 'Offline'),
              visualDensity: VisualDensity.compact,
            ),
          ),
          IconButton(tooltip: 'Settings', onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const SettingsScreen())),
            icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search saved pages…',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _search.text.isEmpty ? null : IconButton(
                onPressed: () { _search.clear(); setState(() {}); },
                icon: const Icon(Icons.clear)),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(children: [
            Text('${filtered.length} saved item(s)'),
            const Spacer(),
            const Text('Sort: '),
            DropdownButton<String>(
              value: _sort,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(value: 'date', child: Text('Newest')),
                DropdownMenuItem(value: 'name', child: Text('Name')),
              ],
              onChanged: (v) => setState(() => _sort = v ?? 'date'),
            ),
            IconButton(
              tooltip: 'Clear all',
              onPressed: vault.items.isEmpty ? null : _clearAll,
              icon: const Icon(Icons.delete_sweep_outlined),
            ),
          ]),
        ),
        if (vault.downloading && vault.progress != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              LinearProgressIndicator(value: vault.progress!.fraction),
              const SizedBox(height: 4),
              Text(vault.progress!.message, style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        Expanded(
          child: filtered.isEmpty
            ? Center(child: Padding(
                padding: const EdgeInsets.all(30),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.offline_bolt_outlined, size: 58, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 12),
                  Text(vault.items.isEmpty ? 'Nothing saved yet' : 'No matching pages',
                    style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 6),
                  Text(vault.items.isEmpty
                    ? 'Tap Add to save a website while you are online.'
                    : 'Try another title or URL.'),
                ]),
              ))
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final item = filtered[index];
                  return SavedItemCard(
                    item: item,
                    onOpen: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => ViewerScreen(item: item))),
                    onRename: () => _rename(item),
                    onDelete: () => _delete(item),
                  );
                },
              ),
        ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => const AddScreen())),
        icon: const Icon(Icons.add),
        label: const Text('Add'),
      ),
    );
  }
}
