import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/vault_service.dart';
import '../services/connectivity_service.dart';
import '../services/settings_service.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({super.key});
  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final _url = TextEditingController();
  bool _wholeSite = false;
  bool _busy = false;

  @override
  void dispose() { _url.dispose(); super.dispose(); }

  Future<void> _save() async {
    final vault = context.read<VaultService>();
    final network = context.read<ConnectivityService>();
    final settings = context.read<SettingsService>();
    if (!network.online) {
      _message('Internet connection is unavailable.');
      return;
    }
    if (settings.wifiOnly && !network.onWifi) {
      _message('Wi-Fi-only is enabled. Connect to Wi-Fi to download.');
      return;
    }
    setState(() => _busy = true);
    try {
      final item = await vault.saveWebsite(
        _url.text, wholeSite: _wholeSite, depth: settings.depth,
      );
      if (!mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      Navigator.pop(context);
      messenger.showSnackBar(
        SnackBar(content: Text('Saved "${item.title}" for offline use.')),
      );
    } catch (e) {
      if (mounted) _message(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String text) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(text)));

  @override
  Widget build(BuildContext context) {
    final vault = context.watch<VaultService>();
    return Scaffold(
      appBar: AppBar(title: const Text('Add website')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        TextField(
          controller: _url,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            labelText: 'Website URL',
            hintText: 'https://example.com/article',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.link),
          ),
        ),
        const SizedBox(height: 18),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Save the whole website'),
          subtitle: const Text('Downloads linked pages on the same domain.'),
          value: _wholeSite,
          onChanged: _busy ? null : (v) => setState(() => _wholeSite = v),
        ),
        const SizedBox(height: 8),
        const Text('The whole-site option follows same-domain links only. The depth limit is controlled in Settings.'),
        const SizedBox(height: 22),
        if (vault.downloading) ...[
          LinearProgressIndicator(value: vault.progress?.fraction),
          const SizedBox(height: 8),
          Text(vault.progress?.message ?? 'Downloading…'),
          Text(vault.progress?.url ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
          TextButton.icon(
            onPressed: () => vault.cancelDownload(),
            icon: const Icon(Icons.cancel_outlined), label: const Text('Cancel download'),
          ),
        ],
        FilledButton.icon(
          onPressed: _busy || vault.downloading ? null : _save,
          icon: const Icon(Icons.download),
          label: Text(_busy ? 'Saving…' : 'Save for offline'),
        ),
      ]),
    );
  }
}
