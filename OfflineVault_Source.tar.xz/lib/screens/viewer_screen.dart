import 'dart:io';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../models/saved_item.dart';

class ViewerScreen extends StatefulWidget {
  final SavedItem item;

  const ViewerScreen({super.key, required this.item});

  @override
  State<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends State<ViewerScreen> {
  late final WebViewController _controller;
  int _progress = 0;
  String? _viewerError;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (value) {
            if (mounted) setState(() => _progress = value);
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;
            // Keep the reader inside the saved archive. External navigation is
            // deliberately blocked so a page cannot silently become an online page.
            if (uri.scheme == 'file' || uri.scheme == 'about') {
              return NavigationDecision.navigate;
            }
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('This page was not saved for offline use.')),
              );
            }
            return NavigationDecision.prevent;
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame != true && mounted) {
              setState(() => _viewerError = 'Some page resources were not available offline.');
            }
          },
        ),
      );
    _loadSavedFile();
  }

  Future<void> _loadSavedFile() async {
    try {
      final file = File(widget.item.entryPath);
      if (!await file.exists()) {
        if (mounted) setState(() => _viewerError = 'The saved HTML file could not be found.');
        return;
      }
      await _controller.loadFile(file.path);
    } catch (error) {
      if (mounted) setState(() => _viewerError = 'Could not open the saved page: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.item.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Reload saved page',
            onPressed: _loadSavedFile,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_progress < 100) LinearProgressIndicator(value: _progress / 100),
          if (_viewerError != null)
            MaterialBanner(
              content: Text(_viewerError!),
              actions: [
                TextButton(
                  onPressed: () => setState(() => _viewerError = null),
                  child: const Text('Dismiss'),
                ),
              ],
            ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
    );
  }
}
